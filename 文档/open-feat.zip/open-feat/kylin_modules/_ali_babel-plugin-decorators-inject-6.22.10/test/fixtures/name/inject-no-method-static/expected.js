'use strict';

var _class;

var _decorators = require('../../../common/decorators');

let B = (0, _decorators.Component)(_class = class B {

  static name() {}
}) || _class;