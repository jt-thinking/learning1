import { Component } from '../../../common/decorators';

@Component
class B {
  name = 'c';
  a() {

  }
}