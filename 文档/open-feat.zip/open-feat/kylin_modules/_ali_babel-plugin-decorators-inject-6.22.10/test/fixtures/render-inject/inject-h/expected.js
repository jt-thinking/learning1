'use strict';

var _class;

var _decorators = require('../../../common/decorators');

let B = (0, _decorators.Component)(_class = class B {

  render() {
    const h = arguments[0];

    return h(
      'div',
      null,
      []
    );
  }
}) || _class;