import { Component } from '../../../common/decorators';

@Component
class B {

  render() {
    
    return <div></div>
  }
}