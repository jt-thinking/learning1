module.exports = require('./lib/loader')
