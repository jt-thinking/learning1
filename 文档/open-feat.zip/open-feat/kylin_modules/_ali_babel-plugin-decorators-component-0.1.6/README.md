# babel-plugin-decorators-component

## options

- className
- propertyName
- watchName
- objectName
- strict
- noJSX


