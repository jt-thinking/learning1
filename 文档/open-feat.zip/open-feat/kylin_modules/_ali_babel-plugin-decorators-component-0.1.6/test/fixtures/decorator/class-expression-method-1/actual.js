import { Component, Property, Watch } from '../../../common/decorators';

@Component
class B {
  methods = {
    a(v) {

    },
    c: (b) => {

    }
  }
  
  d(a) {

  }
}