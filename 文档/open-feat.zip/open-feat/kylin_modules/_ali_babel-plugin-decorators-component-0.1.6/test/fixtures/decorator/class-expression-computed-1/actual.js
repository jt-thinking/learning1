import { Component, Property, Watch } from '../../../common/decorators';

@Component
class B {
  get a() {
    return 1;
  }
  get b() {

  }
  set b(v) {
    
  }
}