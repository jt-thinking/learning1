import { Component, Property, Watch } from '../../../common/decorators';

@Component
class B {

  a(v) {
    console.log(this)
  }
  d(a) {

  }
}