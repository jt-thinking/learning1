function Component() {

}

function Property() {

}

function PropertyIgnore() {

}

Component.Property = Property;

module.exports = {
  Component: Component,
  Property: Property,
  PropertyIgnore: PropertyIgnore
};