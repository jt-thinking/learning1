var runner = require("babel-helper-plugin-test-runner");

runner(__dirname);
