node node_modules/babel-cli/bin/babel.js test-input.js
