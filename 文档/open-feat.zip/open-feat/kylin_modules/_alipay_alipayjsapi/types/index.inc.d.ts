import * as ap from './entry.inc';
export default ap;