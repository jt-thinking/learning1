import * as ap from './entry';
export default ap;