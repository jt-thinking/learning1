
import * as ap from '../types/entry.inc';
export default ap;
