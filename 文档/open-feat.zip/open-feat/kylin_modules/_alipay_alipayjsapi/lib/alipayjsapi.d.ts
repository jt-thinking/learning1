
import * as ap from '../types/entry';
export default ap;
