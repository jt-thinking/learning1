import { Store } from '@ali/kylin-framework';

export default new Store({
  state: {

  },
  mutations: {

  },
  actions: {

  }
});
