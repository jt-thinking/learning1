import { Store } from '@ali/kylin-framework';
import ap from '@alipay/alipayjsapi/lib/alipayjsapi.inc';

export default new Store({
  state: {

  },
  mutations: {

  },
  actions: {

  }
});
